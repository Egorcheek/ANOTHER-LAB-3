public class Lawn implements Landscape{
    public void changeLocation() {
        System.out.print("на лужайку");
    }
}
