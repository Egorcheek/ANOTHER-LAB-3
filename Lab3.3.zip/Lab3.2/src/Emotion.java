public enum Emotion {
    CALM,
    FEAR,
    HORROR
}
