public class Dream {
//set characters
}
