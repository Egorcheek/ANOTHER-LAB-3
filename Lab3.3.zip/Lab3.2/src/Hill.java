public class Hill implements Landscape{
    public void changeLocation() {
        System.out.print("в долину");
    }
}
