public class Dirt {
    public void beTouched() {
        System.out.print("грязи");
    }
}
