public interface Landscape {
    public void changeLocation();
}
