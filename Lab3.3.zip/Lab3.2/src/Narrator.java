public class Narrator {
    public void storyline(String text){
        System.out.println(" ");
        System.out.print(text);
    }
}
