public class Trauma {
    private String description;
    public Trauma(String description){
        this.description = description;
    }
    public String getDescription(){
        return description;
    }
}
