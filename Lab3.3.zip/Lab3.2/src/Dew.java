public class Dew implements TouchableObject {
    public void beTouched() {
        System.out.print("росы");
    }
}
