public enum SleepStatus {
    SLEEP,
    AWAKE
}