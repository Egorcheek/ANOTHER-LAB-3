public class Road implements Landscape{
    public void changeLocation() {
        System.out.print("к дороге");
    }
}
