public interface HurtingObject {
    public String getHurt();
    public int getPainmeter();
    public Trauma getTrauma();
}
