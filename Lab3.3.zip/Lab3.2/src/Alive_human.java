import java.util.ArrayList;

public class Alive_human extends Human {
    private int painLevel = 0;
    private int fearlevel = 0;
    private SleepStatus sleepStatus = SleepStatus.AWAKE;
    public int getPainLevel() {
        return painLevel;
    }

    public int getFearlevel() {
        return fearlevel;
    }

    private void setFearlevel(int fearlevel) {
        this.fearlevel = fearlevel;
    }

    private void setPainLevel(int ppainLevel) {
        painLevel = ppainLevel;
    }

    public Alive_human(String name, String clothes, String place) {
        this.clothes = clothes;
        this.name = name;
        this.place = place;
        this.trauma = new ArrayList<>();
    }

    public void touch (TouchableObject touchableObject){
        System.out.println(" ");
        System.out.print(name);
        System.out.print(" касается ");
        touchableObject.beTouched();
    }
    public void think (String thought){
        System.out.println(" ");
        System.out.print(name);
        System.out.print(" подумал: '");
        System.out.print(thought);
        System.out.print("'");
    }
    public void hurt (HurtingObject hurtingObject){
        System.out.println(" ");
        System.out.print(hurtingObject.getHurt());
        System.out.print(" травмирует ");
        System.out.print(name);
        painLevel = painLevel + hurtingObject.getPainmeter();
        this.addTrauma(hurtingObject.getTrauma());
        this.checkPainLevel();
    }
    private void checkPainLevel(){
        if (painLevel >= 10 && painLevel < 20){
            System.out.println(" ");
            System.out.print(name);
            System.out.print(" вздрогнул от боли! ");
        }
        if (painLevel >= 20 && painLevel < 40){
            System.out.println(" ");
            System.out.print(name);
            System.out.print(" вскрикнул от боли! ");
        }
        if (painLevel >= 40 && painLevel < 60){
            System.out.println(" ");
            System.out.print(name);
            System.out.print(" ОРЕТ ОТ БОЛИ! ");
        }
    }
    private void checkFearLevel(){
        if (fearlevel >= 10 && fearlevel < 20){
            this.feel(Emotion.FEAR);
        }
        if (painLevel >= 20 && painLevel < 40){
            this.feel(Emotion.HORROR);
        }
        if (painLevel < 10){
            this.feel(Emotion.CALM);
        }
    }
    public void feel (Emotion emotion){
        System.out.println(" ");
        System.out.print(name);
        System.out.print(" почувствовал ");


        if(emotion == Emotion.FEAR){
            System.out.print("страх");
        }
        if(emotion == Emotion.HORROR){
            System.out.print("ужас");
        }
        if(emotion == Emotion.CALM){
            System.out.print("спокойствие");
        }
    }

    public void see(Dead_human deadHuman) {
        System.out.println(" ");
        System.out.print(name);
        System.out.print(" видит ");
        System.out.print(deadHuman.getName());
        System.out.print(" в ");
        System.out.print(deadHuman.getPlace());
        fearlevel = fearlevel + 10;
        this.checkFearLevel();
    }
    public void checkTrauma() {
        System.out.println(" ");
        if (trauma.isEmpty()) {
            System.out.println(name + " не имеет травм.");
        } else {
            System.out.println(name + " имеет следующие травмы:");
            for (Trauma ttrauma : trauma) {
                System.out.println("- " + ttrauma.getDescription());
            }
        }
    }
    public void sleep(Dream dream){
        if (this.sleepStatus == SleepStatus.SLEEP){
            System.out.println(" Невозможно уснуть, персонаж уже спит!");
        } else{
            this.sleepStatus = SleepStatus.SLEEP;
        }
    }

}
