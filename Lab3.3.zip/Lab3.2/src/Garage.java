public class Garage implements Landscape{
    public void changeLocation() {
        System.out.print("в гараж");
    }
}
