import java.util.ArrayList;
import java.util.Objects;

public abstract class Human {
    protected String name;
    protected String clothes;
    protected String place;
    protected ArrayList<Trauma> trauma;
    public String getName(){
        return  name;
    }
    //public String getClothes() {
    //    return clothes;
   // } сделать аррау лист как травмы
    public String getPlace() {
        return place;
    }
    protected void setPlace(String place) {
        this.place = place;
    }


    /*public void setClothes(String clothes){
        this.clothes = clothes;
    }
    */
    @Override
    public boolean equals(Object o){
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Human that = (Human) o;
        if (place != that.place) return false;
        return Objects.equals(name, that.name);
    }
   /* @Override
    public boolean hashcode
   */

    public void see(String obj){
        System.out.println(" ");
        System.out.print(name);
        System.out.print(" видит ");
        System.out.print(obj);
    }
    public void see(String obj, String land){
        System.out.println(" ");
        System.out.print(name);
        System.out.print(" видит ");
        System.out.print(obj);
        System.out.print(" в ");
        System.out.print(land);
    }

    public void lookBack(){
        System.out.println(" ");
        System.out.print(name);
        System.out.print(" оглянулся");
    }
    public void move(Landscape landscape){
        System.out.println(" ");
        System.out.print(name);
        System.out.print(" идет ");
        landscape.changeLocation();
    }
    public void addTrauma(Trauma trauma){
        this.trauma.add(trauma);
    }

}





//56 page