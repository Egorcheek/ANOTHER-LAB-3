public interface TouchableObject {
    public void beTouched();
    
}
