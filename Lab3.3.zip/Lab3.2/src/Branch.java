public class Branch implements HurtingObject {
    final int painmeter = 10;

    public int getPainmeter() {
        return painmeter;
    }
    public String getHurt() {
        return "ветка";
    }
    public Trauma getTrauma(){
        return new Trauma("Царапина");
    }
}
